Cara menjalankan dashboard
1. buka terminal
2. jika belum menginstal streamlit dan library lainnya dapat menginstalnya terlebih dahulu.  (library dapat dilihat difile requirements.txt)
3. ketikan streamlit run dashboard.py (sesuaikan dengan path anda)
4. lalu ikuti link yang ditampilkan di terminal (tidak masalah keduanya)