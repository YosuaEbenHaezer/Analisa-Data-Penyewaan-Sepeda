import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Judul Dashboard
st.markdown(
    """
    <div style="background-color: #52595D; padding: 10px; border-radius: 5px;">
        <h2 style="text-align: center;">Dashboard Penyewaan Sepeda</h2>
    </div>
    """, 
    unsafe_allow_html=True
)

# Menambahkan garis pembatas horizontal
st.markdown("<hr>", unsafe_allow_html=True)

# Fungsi untuk memuat data
def load_data():
    hours_df = pd.read_csv('../Data/hour.csv')
    day_df = pd.read_csv('../Data/day.csv')
    return hours_df, day_df

hours_df, day_df = load_data()

# Sidebar untuk memilih visualisasi
visualization = st.sidebar.selectbox(
    "Pilih Visualisasi",
    ["Penyewaan Sepeda Setiap Bulan", "Perbandingan Penyewaan Hari Kerja dan Libur", "Pengaruh Cuaca"]
)

# Visualisasi Penyewaan Berdasarkan Jam (Hours Data)
if visualization == "Penyewaan Sepeda Setiap Bulan":
    agg_data = day_df.groupby('mnth').agg({
    "casual": ["max", "min", "mean"],
    "registered": ["max", "min", "mean"],
    "cnt": ["max", "min", "mean", "std"]
})

    # Flatten MultiIndex columns
    agg_data.columns = ['_'.join(col).strip() for col in agg_data.columns.values]

    # Plot 1: Max, Min, and Mean for Casual Users
    fig1, ax1 = plt.subplots(figsize=(12, 6))
    st.subheader("1. Tampilan penyewaan bagi pengguna casual setiap bulannya ")
    ax1.plot(agg_data.index, agg_data['casual_max'], label='Max Casual Users', marker='o')
    ax1.plot(agg_data.index, agg_data['casual_min'], label='Min Casual Users', marker='o')
    ax1.plot(agg_data.index, agg_data['casual_mean'], label='Mean Casual Users', marker='o')
    ax1.set_title('Casual Users - Max, Min, Mean per Month')
    ax1.set_xlabel('Month')
    ax1.set_ylabel('Number of Casual Users')
    ax1.legend()
    ax1.grid(True)
    st.pyplot(fig1)
    st.write("Penjelasan")
    penjelasan1= """Plot diatas akan menampilkan data max, min, mean dan std pada penyewaan casual.
Jika dilihat dari grafik yang ada penyewaan maximal mengalami peningkatan dari awal bulan hingga ke bulan 2-3 namun ada penurunan dibulan ke-6 lalu naik lagi dipertengahan bulan ke-6 dan kenaikan lagi dipertengahan 8 dan kembali menurun sampai bulan 12.
untuk Rata-ratanya kenaikan secara parabola dari 1 bulan dan mengalami penurunan dari 8 hingga seterusnya."""
    st.write(penjelasan1)

    # Plot 2: Max, Min, and Mean for Registered Users
    fig2, ax2 = plt.subplots(figsize=(12, 6))
    st.subheader("2. Tampilan penyewaan bagi pengguna yang register setiap bulannya ")
    ax2.plot(agg_data.index, agg_data['registered_max'], label='Max Registered Users', marker='o')
    ax2.plot(agg_data.index, agg_data['registered_min'], label='Min Registered Users', marker='o')
    ax2.plot(agg_data.index, agg_data['registered_mean'], label='Mean Registered Users', marker='o')
    ax2.set_title('Registered Users - Max, Min, Mean per Month')
    ax2.set_xlabel('Month')
    ax2.set_ylabel('Number of Registered Users')
    ax2.legend()
    ax2.grid(True)
    st.pyplot(fig2)
    st.write("Penjelasan")
    penjelasan2="""hasil dari plot ini memiliki perbedaan dengan penyewaan casual. pada plot ini menampilkan penyewa yang sudah registrasi.
Gerakan grafik rata-rata seperti gerak parabol mengalami kenaikian dipertengahan bulan namun mengalami penurunan di akhir bulan.
"""
    st.write(penjelasan2)
    
    # Plot 3: Max, Min, Mean, and Std for Total Rentals (cnt)
    fig3, ax3 = plt.subplots(figsize=(12, 6))
    st.subheader("3. Tampilan total penyewaan bagi seluruh pengguna setiap bulannya ")
    ax3.plot(agg_data.index, agg_data['cnt_max'], label='Max Total Rentals', marker='o')
    ax3.plot(agg_data.index, agg_data['cnt_min'], label='Min Total Rentals', marker='o')
    ax3.plot(agg_data.index, agg_data['cnt_mean'], label='Mean Total Rentals', marker='o')
    ax3.fill_between(agg_data.index, agg_data['cnt_mean'] - agg_data['cnt_std'], 
                    agg_data['cnt_mean'] + agg_data['cnt_std'], color='b', alpha=0.2, label='Standard Deviation')
    ax3.set_title('Total Rentals (cnt) - Max, Min, Mean, and Std per Month')
    ax3.set_xlabel('Month')
    ax3.set_ylabel('Number of Rentals')
    ax3.legend()
    ax3.grid(True)
    st.pyplot(fig3)
    st.write("Penjelasan") 
    penjelasan3="""pada tampilan plot ini menampilkan plot dari total seluruh penyewaan.
Untuk rata-rata peminjaman menyentuh angka 2000 dibulan awal naik hingga hampir menyentuh angka 6000 dibulan ke 6 hingga bulan pertengahan 9"""
    st.write(penjelasan3)
    st.write("Kesimpulan")
    kesimpulan="""
-  Ada perbedaan dari max, mean, dan min. max, mean dan minimalnya registred jauh lebih tinggi. Dapat dikatakan bahwa untuk penyewaan registred setiap bulannya memiliki angka lebih tinggi dibandingkan yang casual.
-  Gerakan visualisasi plot mengalami kenaikan diawal bulan namun mengalami penurunan diakhir bulan. baik itu penyewa casual maupun registrai dan total penyewaan.
-  Penyewaan dilakukan paling banyak oleh penyewa yang sudah registrasi
"""
    st.write(kesimpulan)
    
# Visualisasi Penyewaan 
elif visualization == "Perbandingan Penyewaan Hari Kerja dan Libur":
    st.subheader("Perbandingan Penyewaan: Registered dan Casual Pada Hari Kerja dan Hari Libur")
    fig, ax = plt.subplots()
    

    # Grouping data berdasarkan jam dan hari kerja (workingday)
    hourly_rentals = hours_df.groupby(['hr', 'workingday']).agg({
        'cnt': 'sum'  # Menghitung total penyewaan per jam
    }).reset_index()

    # Mengubah nilai 'workingday' menjadi label
    hourly_rentals['day_type'] = hourly_rentals['workingday'].map({0: 'Hari Libur', 1: 'Hari Kerja'})

    # Membuat plot
    plt.figure(figsize=(12, 6))
    sns.barplot(data=hourly_rentals, x='hr', y='cnt', hue='day_type', palette=['orange', 'green'])

    # Memberikan judul dan label pada plot
    plt.title('Jumlah Penyewaan Sepeda Berdasarkan Jam (Hari Kerja dan Hari Libur)', fontsize=14)
    plt.xlabel('Jam', fontsize=12)
    plt.ylabel('Jumlah Penyewaan', fontsize=12)
    plt.xticks(range(0, 24))  # Memberikan label pada sumbu x

    # Menampilkan plot
    plt.tight_layout()
    plt.legend(title='Tipe Hari')

    # Menampilkan plot di Streamlit
    st.pyplot(plt)

    st.write("Penjelasan")
    penjelasan4="""pada plot tersebut menampilkan informasi tentang jam penyewaan, pada hari libur maupun hari kerja.
Berdasarkan plot dapat dilihat bahwa peminjaman dilakukan dihari libur mengalami peningkatan dari jam 8 hingga akhirnya menurun dijam 11 malam. Namun, untuk hari kerja peningkatan penyewaan paling banyak di jam 6 pagi hingga jam 9 pagi dan naik lagi di jam 4 sore hingga menurun di jam 7 malam."""
    penjelasan4b="""
-  Dapat dilihat bahwa penyewaan sepeda dihari kerja mengalami peningkatan dijam masuk kerja dan pada pulang kerja. Sehingga dapat dikatakan bahwa orang sering menyewa sepeda sebagai transportasi untuk pergi kerja atau mengantar anak kesekolah
-  Penyewaan dihari libur mulai mengalami peningkatan pada jam 8 dan kembali menurun disore hari.
-  Dari plot dapat dilihat bahwa penyewaan paling banyak dilakukan pada hari kerja. Namun, ketika tengah malam penyewaan lebih banyak pada hari libur"""
    st.write(penjelasan4, penjelasan4b)
# Visualisasi Pengaruh Cuaca
elif visualization == "Pengaruh Cuaca":
    st.subheader("Pengaruh Cuaca Terhadap Penyewaan Sepeda")
    
    # Menghitung agregasi berdasarkan kondisi cuaca (weathersit)
    agg_weathersit = hours_df.groupby('weathersit').agg({
        "casual": ["max", "min", "mean"],
        "registered": ["max", "min", "mean"],
        "cnt": ["max", "min", "mean", "std"]
    }).reset_index()

    # Mengatur posisi bar
    bar_width = 0.2
    index = range(len(agg_weathersit))

    # Membuat plot
    plt.figure(figsize=(12, 6))

    # Menambahkan bar untuk casual users
    plt.bar(index, agg_weathersit[('casual', 'mean')], bar_width, label='Rata-rata Kasual', color='orange')
    plt.bar([i + bar_width for i in index], agg_weathersit[('registered', 'mean')], bar_width, label='Rata-rata Registrasi', color='blue')
    plt.bar([i + 2 * bar_width for i in index], agg_weathersit[('cnt', 'mean')], bar_width, label='Rata-rata Total Penyewaan', color='green')

    # Menambahkan label dan judul
    plt.xlabel('Kondisi Cuaca (Weathersit)', fontsize=12)
    plt.ylabel('Jumlah Penyewaan', fontsize=12)
    plt.title('Rata-rata Penyewaan Sepeda Berdasarkan Kondisi Cuaca', fontsize=14)
    plt.xticks([i + bar_width for i in index], agg_weathersit['weathersit'], rotation=45)
    plt.legend(title='Kategori')

    # Menambahkan teks penjelasan di bawah plot
    plt.figtext(0.5, -0.1,
                "1 = Cerah, sedikit awan, sebagian berawan.\n"
                "2 = Kabut + Berawan, Kabut + Awan pecah, Kabut + sedikit awan, Kabut.\n"
                "3 = Salju ringan, Hujan ringan + badai petir + awan tersebar, Hujan ringan + awan tersebar.\n"
                "4 = Hujan deras + pellet es + badai petir + kabut, Salju + kabut.",
                ha='center', fontsize=10)
    
    penjelasan5="""Pada Plot tersebut terdapat perbedaan penyewaan sepeda baik dari registred maupun casual dan total pengalami penurunan yang sama.
    No 3
-  Kondisi cuaca sangat mempengaruhi penyewaan sepeda baik secara total maupun casual dan registred.
saat kondisi ekstrim atau bersalju kabut dan lainnya pemesanan mengalami penurunan sedangkan saat cuaca cerah penyewaan sepeda tinggi
-  Dapat dilihat pada plot angka 1 memiliki pesanan yang lebih tinggi, lalu nomor 2 dibawahnya setelah itu nomor 3 dan penyeweaan terendah ketika cuaca pada kondisi nomor 4.
"""

    # Menampilkan plot 
    plt.tight_layout()
    st.pyplot(plt)
    st.write("Penjelasan")
    st.write(penjelasan5)


